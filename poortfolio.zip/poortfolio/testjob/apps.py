from django.apps import AppConfig


class TestjobConfig(AppConfig):
    name = 'testjob'
